/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    Scanner sc= new Scanner(System.in);
	    int n= 1541; 
	    int temp=n;
	    int rev=0;
	    
	    while(temp!=0){
	        temp=rev * 10 + temp % 10;
	        temp/= 10;
	    }
		System.out.println(n == rev);
	}
}
