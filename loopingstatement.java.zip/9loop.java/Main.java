/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc =new Scanner(System.in);
	    int a= sc.nextInt();
	    int b= sc.nextInt();
	    int lcm;
	    lcm= (a>b) ? a : b;
	    while(true){
	        if(lcm % a==0 && lcm % b == 0){
	        System.out.println(lcm);
	        break;
	    }
	    lcm++;
	    }
	    	
	}
}
